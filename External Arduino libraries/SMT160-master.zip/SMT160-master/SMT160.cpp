#include "SMT160.h"


SMT160::SMT160()
{
  // initialize this instance's variables
  //pin = _pin;
  //timeout = 3000;

  // do whatever is required to initialize the library
  //pinMode(pin, INPUT);
}

// Public Methods //////////////////////////////////////////////////////////////
// Functions available in Wiring sketches, this library, and other libraries

int SMT160::getTemp(unsigned int pin,unsigned long _tout)
{
  // eventhough this function is public, it can access
  // and modify this library's private variables
  pinMode(pin, INPUT);
  //timeout = _tout;
  unsigned long th = pulseIn(pin, HIGH, _tout);
  unsigned long t = pulseIn(pin, LOW, _tout);
  if(t && th)
  {
    t += th;
    return ((long)(((th * 1000000) / t) - 320000)) / 47;
  }
  return 0xffff;
}
