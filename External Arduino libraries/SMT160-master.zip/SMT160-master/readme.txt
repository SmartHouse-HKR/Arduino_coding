SMT160 - Function and support Arduino library for the SMT160/SMT172 temperature sensors.
